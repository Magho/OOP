package eg.edu.alexu.csd.oop.db.cs55;

public class ICreate {

}
