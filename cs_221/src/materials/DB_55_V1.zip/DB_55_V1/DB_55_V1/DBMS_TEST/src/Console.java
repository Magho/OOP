import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import eg.edu.alexu.csd.oop.db.Database;
import eg.edu.alexu.csd.oop.db.cs55.DataBaseAdapter;
import eg.edu.alexu.csd.oop.jdbc.cs55.Utilities;

import javax.swing.JTextField;

public class Console{

    JFrame frame = new JFrame ();
    private JTextField textField;
    Database db = new DataBaseAdapter();
	Utilities utilities = new Utilities();
	Object[][] res = null;
	int updateRows;
	ArrayList<String> coloumnsName = new ArrayList<String>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Console window = new Console();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Console() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		JPanel middlePanel = new JPanel ();
	    middlePanel.setBorder ( new TitledBorder ( new EtchedBorder (), "Display Area" ) );

	    // create the middle panel components

	    JTextArea display = new JTextArea ( 16, 58 );
	    display.setBackground(new Color(0, 0, 0));
	    display.setForeground(Color.WHITE);
	    display.setEditable ( false ); // set textArea non-editable
	    JScrollPane scroll = new JScrollPane ( display );
	    scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );

	    //Add Textarea in to middle panel
	    middlePanel.add ( scroll );
	    
	    

	    
	    // My code
	    frame.getContentPane().add ( middlePanel );
	    frame.pack ();
	    frame.setLocationRelativeTo ( null );
	    frame.setVisible ( true );
	    
	    Action action = new AbstractAction()
	    {
	    @Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
				 int flag = 0;
					
						try {
							String sql = textField.getText();
							textField.setText("");
							String response = new String();
							String query = sql.toLowerCase().trim();
							if(query.matches("create.*")||query.matches("drop.*")){
								response =	db.executeStructureQuery(query) + "";
								
							}else if(query.matches("select.*")){
								res = db.executeQuery(query);
								flag = 1;
							}else if(query.matches("insert.*")){
								response = db.executeUpdateQuery(query) + "";
							}else if(query.matches("delete.*")||query.matches("update.*")){
								response = db.executeUpdateQuery(query) + "";
							}
							display.setText(display.getText() + response + "\n\n");
							if(flag == 1) {
								coloumnsName = utilities.getSelectedColumns(sql);
								if(coloumnsName.size() == 0){
									coloumnsName = ((DataBaseAdapter)db).SelectedTable.getColoumnsNames();
								}
								for(int j = 0; j < res.length + 1; j++) {
									for(int i = 0; i < coloumnsName.size(); i++) {
										if(j == 0) {
											if(i == 0) {
												display.setText(display.getText() + "|" + coloumnsName.get(i) + "|" + "\n");
											}
											else {
												display.setText(display.getText() + coloumnsName.get(i) + "|" + "\n");
											}
											
										}
										else {
											if(i == 0) {
												display.setText(display.getText() +"|" + res[j-1][i]);
												for(int v = 0; v < coloumnsName.get(i).length() - res[j-1][i].toString().length()-1; v++ ) {
													display.setText(display.getText() + " ");
												}
												display.setText(display.getText() +  "|" + "\n");
											
											}
											else {
												display.setText(display.getText() +res[j-1][i]);
												for(int v = 0; v < coloumnsName.get(i).length() - res[j-1][i].toString().length(); v++ ) {
													display.setText(display.getText() + " ");
												}
												display.setText(display.getText() +  "|" + "\n");
											}
										}
										for(int l = 0; l < coloumnsName.get(i).length()+1; l++) {
											display.setText(display.getText() +"-");
										}
										display.setText(display.getText() + "\n");
										flag = 0;
									}
								}
							}
							
							
						}catch (Exception ee) {
							display.setText(display.getText() + ee.getMessage() + "\n\n");
						}

			 
		}
	    
	};
	
	textField = new JTextField();
    scroll.setColumnHeaderView(textField);
    textField.setColumns(10);
    textField.addActionListener(action);
	    
	    
	    
	    
	    
	    
	}

	


}
