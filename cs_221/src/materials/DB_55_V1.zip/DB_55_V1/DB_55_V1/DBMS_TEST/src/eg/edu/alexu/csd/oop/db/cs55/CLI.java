package eg.edu.alexu.csd.oop.db.cs55;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import eg.edu.alexu.csd.oop.db.Database;

public class CLI {

	public static void main(String[] args) {
		int flag = 0;
		Database db = new DataBaseAdapter();
		Scanner sc = new Scanner(System.in);
		Utilities utilities = new Utilities();
		Object[][] res = null;
		int updateRows;
		ArrayList<String> coloumnsName = new ArrayList<String>();
		while(true) {
			try {
				String sql = sc.nextLine();
				boolean response = false;
				String query = sql.toLowerCase().trim();
				if(query.matches("create.*")||query.matches("drop.*")){
					response =	db.executeStructureQuery(query);
					
				}else if(query.matches("select.*")){
					res = db.executeQuery(query);
					response = true;
					flag = 1;
				}else if(query.matches("insert.*")){
					updateRows = db.executeUpdateQuery(query);
					response = true;
				}else if(query.matches("delete.*")||query.matches("update.*")){
					updateRows = db.executeUpdateQuery(query);
					response = true;
				}
				System.out.println(response);
				if(flag == 1) {
					coloumnsName = utilities.getSelectedColumns(sql);
					if(coloumnsName.size() == 0){
						coloumnsName = ((DataBaseAdapter)db).SelectedTable.getColoumnsNames();
					}
					for(int j = 0; j < res.length + 1; j++) {
						for(int i = 0; i < coloumnsName.size(); i++) {
							if(j == 0) {
								if(i == 0) {
									System.out.println("|" + coloumnsName.get(i) + "|");
								}
								else {
									System.out.println(coloumnsName.get(i) + "|");
								}
								
							}
							else {
								if(i == 0) {
									System.out.print("|" + res[j-1][i]);
									for(int v = 0; v < coloumnsName.get(i).length() - res[j-1][i].toString().length()-1; v++ ) {
										System.out.print( " ");
									}
									System.out.println( "|");
								
								}
								else {
									System.out.print(res[j-1][i]);
									for(int v = 0; v < coloumnsName.get(i).length() - res[j-1][i].toString().length(); v++ ) {
										System.out.print( " ");
									}
									System.out.println( "|");
								}
							}
							for(int l = 0; l < coloumnsName.get(i).length()+1; l++) {
								System.out.print("-");
							}
							System.out.println();
							flag = 0;
						}
					}
				}
				
			}catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
