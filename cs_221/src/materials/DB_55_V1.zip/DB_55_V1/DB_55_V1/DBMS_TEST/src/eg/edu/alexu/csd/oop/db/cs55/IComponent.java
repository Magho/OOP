package eg.edu.alexu.csd.oop.db.cs55;

public interface IComponent {
	
	public String getName ();
	public void setName (String name);
	public long getSize();
}
