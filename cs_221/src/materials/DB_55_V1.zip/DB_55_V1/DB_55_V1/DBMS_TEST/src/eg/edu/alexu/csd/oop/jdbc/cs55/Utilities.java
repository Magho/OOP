package eg.edu.alexu.csd.oop.jdbc.cs55;

import java.util.ArrayList;

public class Utilities {

	public static ArrayList<String> getSelectedColumns(String SQLCommand){
		SQLCommand = removeUnusedSpaces(SQLCommand).toLowerCase();
		String processedSQLCommand = new String();
		processedSQLCommand = SQLCommand.substring(0, SQLCommand.length());
		ArrayList<String> coloumnsName = new ArrayList<String>();
		boolean isStarExist = processedSQLCommand.toLowerCase().contains("*");
		boolean isWhereExist = processedSQLCommand.toLowerCase().contains("where");
		if (!isStarExist) {
			coloumnsName = new ArrayList<>();
			String[] splitedColumnsNames;
			String subColumnsNames = processedSQLCommand.substring(processedSQLCommand.indexOf(" ") + 1,
					processedSQLCommand.indexOf("from") - 1);
			if (subColumnsNames.contains(",")) {
				splitedColumnsNames = subColumnsNames.split(",");

				for (String s : splitedColumnsNames) {
					coloumnsName.add(s);
				}
			} 
			else {
				coloumnsName.add(subColumnsNames);
			}
		}
		return coloumnsName;
	}
	public static String removeUnusedSpaces(String line){
		String work = line;
		work = work.replaceAll("\n", " ");
		work = work.replaceAll("[(]", " (");
		work = work.replaceAll("[)]", ") ");
		work = work.trim();
		work = work.replaceAll("\\s+", " ");
		work = work.replaceAll("\\s+;", ";");
		work = work.replaceAll("([(])\\s*", "(");
		work = work.replaceAll("\\s*([)])", ")");
		work = work.replaceAll("\\s*([,])\\s*", ",");
		work = work.replaceAll("\\s+([<>=][=]?)\\s+", "$1");
		return work;
	}
}
